# CS246-Chess
Members:
Julianne Jorda
