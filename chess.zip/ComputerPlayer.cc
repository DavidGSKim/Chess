#include "ComputerPlayer.h"
#include <string>
#include <iostream>

ComputerPlayer::ComputerPlayer() {}

ComputerPlayer::~ComputerPlayer() {}

string ComputerPlayer::level1()
{
    return "Sorry!!";
}

string ComputerPlayer::level2()
{
    return "Sorry!!";
}

string ComputerPlayer::level3()
{
    return "Sorry!!";
}