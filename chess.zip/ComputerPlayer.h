#ifndef __COMPUTERPLAYER__
#define __COMPUTERPLAYER__

#include "Player.h"

class ComputerPlayer
{
public:
    ComputerPlayer();
    ~ComputerPlayer();
    string level1();
    string level2();
    string level3();
};

#endif